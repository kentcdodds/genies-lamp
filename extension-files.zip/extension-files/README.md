genie-extension
===============

A Chrome Extension that put's genie's lamp on any page you're on.
